from pycorenlp.corenlp import StanfordCoreNLP
