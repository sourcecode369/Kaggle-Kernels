from pytest_mock.plugin import *
from pytest_mock.plugin import _get_mock_module
